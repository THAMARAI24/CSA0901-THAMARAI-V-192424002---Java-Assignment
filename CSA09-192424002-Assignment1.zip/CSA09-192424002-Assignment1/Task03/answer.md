
# TASK 3 – DESIGN THE CONTROL LOGIC

## 1. Introduction

Control logic determines how the Campus Smart-Parking System allocates parking slots, calculates parking charges and handles unavailable spaces.

I use looping statements to search the parking facility and conditional statements to validate slots and calculate fees.

The two major operations are slot allocation and parking fee calculation.

## 2. Algorithm for Slot Allocation

The system searches the parking facility floor by floor and slot by slot. When it finds the first available slot, it assigns the vehicle registration number and returns the floor and slot positions.

If no free slot is available, the method returns null.

### Pseudocode – Allocate Slot

```text
ALGORITHM AllocateSlot(vehicleNo)

INPUT: Vehicle registration number
OUTPUT: Allocated floor and slot, or NULL

BEGIN
    FOR each floor f in the parking facility
        FOR each slot s in floor f

            IF slots[f][s] is NULL THEN
                slots[f][s] = vehicleNo

                RETURN {f, s}
            END IF

        END FOR
    END FOR

    RETURN NULL
END

```

## 3. Algorithm for Releasing a Slot

Before releasing a slot, the system validates the floor number and slot number. It also checks whether the selected slot is occupied.

### Pseudocode – Release Slot

```text
ALGORITHM ReleaseSlot(floor, slot)

INPUT: Floor number and slot number
OUTPUT: TRUE if released, otherwise FALSE

BEGIN
    IF floor is outside the valid floor range THEN
        RETURN FALSE
    END IF

    IF slot is outside the valid range of that floor THEN
        RETURN FALSE
    END IF

    IF slots[floor][slot] is NULL THEN
        RETURN FALSE
    END IF

    slots[floor][slot] = NULL

    RETURN TRUE
END
```

## 4. Algorithm for Parking Fee Calculation

The parking fee depends on the vehicle category and the parking duration.

For this example, I assume the following pricing structure:

| Parking Duration | Charge |
|---|---:|
| First started hour | Rs. 30 |
| Each additional started hour | Rs. 20 |
| Maximum daily parking fee | Rs. 200 |

The fee is calculated by converting the parking duration into billable hours. Every started hour is charged as a complete hour.

### Pseudocode – Calculate Parking Fee

```text
ALGORITHM CalculateFee(minutes, ratePerHour)

INPUT: Parking duration in minutes and hourly rate
OUTPUT: Total parking fee

BEGIN
    IF minutes < 0 THEN
        RETURN INVALID
    END IF

    IF minutes = 0 THEN
        RETURN 0
    END IF

    hours = (minutes + 59) DIV 60

    IF hours = 1 THEN
        fee = 30
    ELSE
        fee = 30 + (hours - 1) * 20
    END IF

    IF fee > 200 THEN
        fee = 200
    END IF

    RETURN fee
END
```

The above fee slab is an illustrative assumption. In the complete system, the hourly rate will be determined by the vehicle category.

## 5. Use of Control Statements

### For Loop
The nested for loops search all floors and slots systematically.

### If-Else
Conditional statements check whether a slot is free and determine the applicable parking charge.

### Break
The break statement terminates a loop when further searching is unnecessary. In the allocation algorithm, returning immediately is even more efficient.

### Continue
The continue statement skips an unsuitable or occupied slot and proceeds to the next slot.

### Return
The return statement immediately sends the allocated position or calculated result back to the calling method.

## 6. Handling Unavailable Slots

If every slot is occupied, the allocation method returns null. The ParkingService can then display an appropriate message such as:

"No parking slots available."

The system must not overwrite an occupied slot or issue a ticket without successfully allocating a suitable slot.

## 7. Alternative Concept: Free-Slot Stack

Instead of scanning every slot, the system can maintain a separate stack of free slot positions for each floor.

Each stack stores the available slot numbers.

During allocation:
1. Check whether a floor has any free slots.
2. Select a floor with an available slot.
3. Pop a free slot position from its stack.
4. Mark the slot as occupied.
5. Return the allocated position.

During release:
1. Validate the floor and slot.
2. Check whether the slot is occupied.
3. Mark it as free.
4. Push the slot position back into its floor's stack.

A free-slot counter can also be maintained for each floor to identify floors that contain available spaces.

## 8. Complexity Analysis

Let:
- F = Number of floors.
- S = Maximum number of slots per floor.
- N = Total number of slots.

| Operation | Scanning Approach | Stack Approach |
|---|---|---|
| Allocate | O(F × S) worst case | O(1) |
| Release | O(1) with known position | O(1) |
| Extra space | O(1) | O(N + F) |

In the scanning approach, allocation may examine every slot before finding an available one.

In the stack approach, allocation and release take constant time because a free position can be obtained or restored directly.

The stack approach requires additional memory to maintain free-slot information. It must also ensure that a slot is not pushed into the stack more than once.

## 9. Conclusion

The scanning approach is simple, easy to implement and suitable for the initial parking facility.

The stack-based approach is more efficient for a large parking facility because it reduces allocation time from O(F × S) to O(1).

For the initial implementation, I select the scanning approach because it is straightforward and satisfies the parking requirements. The stack-based approach can be introduced later if the facility becomes significantly larger.

